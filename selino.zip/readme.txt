Introducing, Selino Family. An elegant, classy with a fashionable touch family typeface.

Selino Typeface is perfectly suitable for layout design for quotes or body copy, best used as a display for headings, logos, branding, magazines, product packaging, invitations. logotypes, and much more. Don't wait to add this luxury font family to your collection and start designing straight away.

Free for personal use only

Buy a license:
https://www.creativefabrica.com/product/selino/